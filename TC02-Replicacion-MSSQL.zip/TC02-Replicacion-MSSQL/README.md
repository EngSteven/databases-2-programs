# SQL Server AlwaysOn con contenedores

Este código utiliza dos imágenes de Docker de SQL Server para configurar AlwaysOn Read-Scale/Sin cluster AlwaysOn.

## Cómo hacerlo

1. Ejecute el siguiente comando en este directorio:

```cmd
docker-compose up
```

Tomará aproximadamente 2 minutos configurar el entorno.

En su terminal, debería ver algo como esto:

```cmd
...
db1    | ##      Ejecución del script AOAG completada     ##
...
db2    | ##      Ejecución del script AOAG completada     ##
...
```

2. Conéctese a las instancias de SQL Server utilizando el usuario sa y la contraseña listada en el archivo docker-compose.yml.

3. Cuando haya terminado, limpie el entorno ejecutando:

```cmd
docker-compose down
```

## Conectándose a SQL Server

- Conéctese al réplica primaria usando SQL Server Management Studio (SSMS) utilizando localhost,2500.
- Conéctese a la réplica secundaria usando SQL Server Management Studio (SSMS) utilizando localhost,2600.
- Contraseña SA especificada en el archivo docker-compose.yml.

## Failover

- Solo un failover forzado funciona en este tipo de configuración. Para realizar un failover, conéctese a la secundaria (localhost,2600) y ejecute el comando:
ALTER AVAILABILITY GROUP AG1 FORCE_FAILOVER_ALLOW_DATA_LOSS;

## Solución de problemas

- Si recibe errores de inicio de sesión de sa, ajuste los valores de INIT_WAIT en el archivo docker-compose.yml.
A veces, dependiendo del sistema, las tareas de inicio del contenedor pueden tardar más y la secuencia de inicio podría intentar comenzar a configurar AlwaysOn antes de que SQL Server esté listo.

- Asegúrese de que los scripts de shell (*.sh) siempre tengan finales de línea 'LF'. Si por alguna razón tienen finales de línea al estilo de Windows, los scripts no se ejecutarán.

## Imágenes de contenedor de RHEL MSSQL

<https://catalog.redhat.com/software/containers/mssql/rhel/server/5ba50865f5a0de06555a2ee7?container-tabs=overview>